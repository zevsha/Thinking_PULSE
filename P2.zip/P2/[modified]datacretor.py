import random
import os
import sys
import pickle
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from utils import data_partition, SeqDataset, SeqDataset_Inference
import numpy as np
import torch
import json

with open(f'/storage/Pervez/Video_Games_text_name_dict.json', 'rb') as ft:
        text_name_dict = pickle.load(ft)


class SeqDatasetWithReason(SeqDataset):
    """
    Extends SeqDataset to also return a `reason` string per example.
    """
    def __init__(self, user_train, usernum, itemnum, maxlen, reasons):
        super().__init__(user_train, usernum, itemnum, maxlen)
        #assert len(reasons) == len(self.user_train_windows)
        self.reasons = reasons

    def __getitem__(self, idx):
        # original SeqDataset returns: u, seq, pos_seq, neg_seq
        u, seq, pos, neg = super().__getitem__(idx)
        target_pos=pos[-1] if isinstance(pos, (list,np.ndarray, torch.Tensor)) else pos
        # add your reason
        reason = self.reasons.get( (int(u), int(target_pos)), "")
        return u, seq, pos, neg, reason
    
class SeqDatasetInferenceWithReason(SeqDataset_Inference):
    """
    Extends SeqDataset_Inference to also return a `reason` string per example.
    """
    def __init__(self, user_train, user_valid, user_test, user_list, itemnum, maxlen, reason_map):
        super().__init__(user_train, user_valid, user_test, user_list, itemnum, maxlen)
        #assert len(reasons) == len(self.user_list_windows)
        self.reason_map = reason_map

    def __getitem__(self, idx):
        # original SeqDataset returns: u, seq, pos_seq, neg_seq
        u, seq, pos, neg = super().__getitem__(idx)
        # add your reason
        rank=0
        target_pos=pos[-1] if isinstance(pos, (list,np.ndarray, torch.Tensor)) else pos
        reason = self.reason_map.get( (int(u), int(target_pos)), "")
        #print(f"DEBUG idx={idx},user={u},pos={pos},reason={repr(reason)}")
        return u, seq, pos, neg, rank, reason





def make_candidate_text(interact_ids, candidate_num, target_item_id, target_item_title):
    neg_item_id = []
    max_attempts = 50  # Prevent infinite loop
    attempts = 0
    item_num=6531

    interact_ids = set(interact_ids)
    
    while len(neg_item_id) < 50 and attempts < max_attempts:
        t = np.random.randint(1, item_num + 1)
        if t not in interact_ids and t not in neg_item_id:
            neg_item_id.append(t)
        attempts += 1

    # If not enough negatives were found, fill with randoms
    if len(neg_item_id) < 50:
        all_items = set(range(1, item_num + 1))
        remaining_candidates = list(all_items - interact_ids - set(neg_item_id))
        needed = 50 - len(neg_item_id)
        neg_item_id.extend(random.sample(remaining_candidates, min(len(remaining_candidates), needed)))

    random.shuffle(neg_item_id)

    candidate_ids = [target_item_id]
    candidate_text = [target_item_title + '[CandidateEmb]']

    for neg_candidate in neg_item_id[:candidate_num - 1]:
        text = find_item_text_single(neg_candidate, title_flag=True, description_flag=False)
        candidate_text.append(text + '[CandidateEmb]')
        candidate_ids.append(neg_candidate)

    random_ = np.random.permutation(len(candidate_text))
    candidate_text = np.array(candidate_text)[random_]
    candidate_ids = np.array(candidate_ids)[random_]

    return ','.join(candidate_text), candidate_ids


def make_interact_text(interact_ids, interact_max_num):
    interact_item_titles_ = find_item_text(item=interact_ids, title_flag=True, description_flag=False)
    interact_text = []
    if interact_max_num == 'all':
        for title in interact_item_titles_:
            interact_text.append(title + '[HistoryEmb]')
    else:
        for title in interact_item_titles_[-interact_max_num:]:
            interact_text.append(title + '[HistoryEmb]')
        interact_ids = interact_ids[-interact_max_num:]
        
    interact_text = ','.join(interact_text)
    return interact_text, interact_ids


def find_item_text(item, title_flag=True, description_flag=True):
    t = 'title'
    d = 'description'
    t_ = 'No Title'
    d_ = 'No Description'
    if title_flag and description_flag:
        return [f'"{text_name_dict[t].get(i,t_)}, {text_name_dict[d].get(i,d_)}"' for i in item]
    elif title_flag and not description_flag:
        return [f'"{text_name_dict[t].get(i,t_)}"' for i in item]
    elif not title_flag and description_flag:
        return [f'"{text_name_dict[d].get(i,d_)}"' for i in item]

def find_item_text_single(item, title_flag=True, description_flag=True):
    t = 'title'
    d = 'description'
    t_ = 'No Title'
    d_ = 'No Description'
    if title_flag and description_flag:
        return f'"{text_name_dict[t].get(item,t_)}, {text_name_dict[d].get(item,d_)}"'
    elif title_flag and not description_flag:
        return f'"{text_name_dict[t].get(item,t_)}"'
    elif not title_flag and description_flag:
        return f'"{text_name_dict[d].get(item,d_)}"'


dataset = data_partition('Video_Games', path=f'/storage/SFTrecc/Video_Games.txt')
[user_train, user_valid, user_test, usernum, itemnum] = dataset
print("usernum: "+str(usernum))
print("itemnum: "+ str(itemnum))
print("train len: "+str(len(user_train)))
print("valid len: "+str(len(user_valid)))
print("test len: "+str(len(user_test)))

#stage2=[ json.loads(l) for l in open('/storage/SFTrecc/properluxurybeautyfullformat_stage2inter.json', 'r')]
#reasons= {
#        (ex['user_id'], ex['pos']): ex['reason'] for ex in stage2 }
#print(next(iter(reasons.items())))
#print(reasons.get( (1, 1305), ""))
#reason_map= {
#        (int(ex['user_id']), int(ex['seq'][-1])): ex['reason'] for ex in stage2 }
#
#reasons = {
#    (int(ex['user_id']), int(ex['seq'][-1])): ex['reason']
#    for ex in stage2
#}


#train_data_set=SeqDatasetWithReason(user_train, usernum, itemnum, 50, reasons)
#for i in range(2):
#    u, seq, pos, neg, reason = train_data_set[i]
#    key = (int(u), int(pos[-1]))
#    print(f"Lookup key: {key}")
#    if key not in reasons:
#        print("❌ Not found in reasons!")
#    else:
#        print("✅ Found! Reason:", reasons[key])
#

train_data_set=SeqDataset(user_train, usernum, itemnum,50)
#for i in range(3,4):
#    print(train2_data_set[i])
    

#if usernum>10000:
#    users = random.sample(range(1, usernum + 1), 10000)
#else:
users = range(1, usernum + 1)
#
user_list = []
for u in users:
    if len(user_train[u]) < 1 or len(user_test[u]) < 1: continue
    user_list.append(u)

#user_pos_set=set((item['user_id'],item['pos']) for item in stage2)
#user_list = []
#for (u,pos) in user_pos_set:
#        # skip if no train history _or_ no valid history
#    if len(user_train.get(u,[])) < 1 or len(user_valid.get(u,[])) < 1:
#        continue
#    user_test[u] = [pos]
#    user_list.append(u)


inference_data_set = SeqDataset_Inference(user_train, user_valid, user_test, user_list, itemnum, 50)
#inference_data_set = SeqDatasetInferenceWithReason(user_train, user_valid, user_test, user_list, itemnum, 50,reason_map)
#cnt=[]
#for i in range(len(inference_data_set)):
#    u,seq,pos,neg,rank,reason=inference_data_set[i]
#    cnt.append(u)
#print(cnt)

import json, numpy as np, torch

# Load adaptive reasons into a dict
user_reasons = {}
with open("/storage/Pervez/[Sbert_videogames]scored_rationales_tree_of_thoughts.jsonl", "r") as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
            uid = obj.get("user_id")
            if isinstance(uid, str) and uid.isdigit():
                uid = int(uid)
            if uid is not None:
                user_reasons[uid] = obj
        except json.JSONDecodeError:
            print("Skipping bad line")

text_input, text_output, sft_data = [], [], []

for i in range(len(inference_data_set)):
    u, seq, pos, neg = inference_data_set[i]
    #if u not in user_reasons:
    #    continue 
    if user_reasons.get(u) is None:
        continue
    
    target_item_id = pos[-1] if isinstance(pos, (list, np.ndarray, torch.Tensor)) else pos
    target_item_title = find_item_text_single(target_item_id, title_flag=True, description_flag=False)

    interact_text, interact_ids = make_interact_text(seq[seq > 0], 3)
    candidate_num = 5
    candidate_text, candidate_ids = make_candidate_text(seq[seq > 0], candidate_num, target_item_id, target_item_title)
    
     
    
    candidate_set = set(candidate_ids)  # faster lookup

# filter out overlaps
    filtered_interact_ids = [item for item in interact_ids if item not in candidate_set]
    
    # get titles for filtered history
    filtered_interact_titles = find_item_text(
        item=filtered_interact_ids,
        title_flag=True,
        description_flag=False
    )
    
    # convert to string with [HistoryEmb]
    filtered_interact = ", ".join([title + "[HistoryEmb]" for title in filtered_interact_titles])

            

    input_text = f" {u} : "
    input_text += "interacted items: " + str(filtered_interact)
    input_text += " candidate items: " + str(candidate_text)

    
    #entry = user_reasons.get(u)
    #ada_reason = None
    #if entry:
    #    #if entry.get("best_prompt") == "prompt1":
    #    ada_reason = entry.get("reason1", "")
    ##    #else:
    ##    #    ada_reason = entry.get("reason2", "")
##
    #if ada_reason:
    #    input_text += " Let me think: " + ada_reason.strip()
    #else:
    #    input_text += " Let me think: Based on your history..."

    input_text += ". The recommendation is "

    text_input.append(input_text)
    sft_data.append({"input": input_text, "output": target_item_title})

with open("/storage/Pervez/normal_run_1_5/[Sbert_ablat]infer_vidgames_full.json","w") as f:
    for e in sft_data:
        f.write(json.dumps(e)+ "\n")