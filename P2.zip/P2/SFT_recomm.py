#import os
#import torch
#from datasets import load_dataset
#from datasets import Dataset
#from peft import get_peft_model, LoraConfig, prepare_model_for_kbit_training
#from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
#from trl import SFTConfig, SFTTrainer
#
## 1) Environment and quantization setup
#os.environ["NCCL_IB_DISABLE"]    = "1"
#os.environ["NCCL_P2P_DISABLE"]   = "1"
##os.environ["CUDA_VISIBLE_DEVICES"] = "1"      # use your target GPU index
#
#bnb_config = BitsAndBytesConfig(
#    load_in_4bit=True,
#    bnb_4bit_quant_type="nf4",
#    bnb_4bit_use_double_quant=True,
#    bnb_4bit_compute_dtype=torch.float16,
#)
#
#from transformers import TrainerCallback
#
#import pandas as pd
#df=pd.read_json("/storage/Pervez/normal_run_1_5/[LL_tot]train[7k]_primepantry_full.json", lines=True)
#
#class PrintDebugCallback(TrainerCallback):
#    def on_step_end(self, args, state, control, **kwargs):
#        print(f"[DEBUG] Step: {state.global_step}, Epoch: {state.epoch:.2f}")
#        return control
#
#
#
## 2) Load pretrained LLM in 4‑bit
#repo_id = "microsoft/Phi-4-mini-instruct"
#model = AutoModelForCausalLM.from_pretrained(
#    repo_id,
#    device_map="auto",
#    quantization_config=bnb_config,
#)
#model = prepare_model_for_kbit_training(model)
#
##for name, module in model.named_modules():
##    if isinstance(module, torch.nn.Linear):
##        print(name)
#
#
## 3) Wrap with LoRA adapter
#peft_config = LoraConfig(
#    r=8,                                    # LoRA rank
#    lora_alpha=16,
#    target_modules=["o_proj", "qkv_proj"],    # tune Q/V projections
#    lora_dropout=0.05,
#    bias="none",
#    task_type="CAUSAL_LM",
#)
#model = get_peft_model(model, peft_config)
#
## 4) Load your JSONL SFT dataset
##    Assumes each line: {"input": "...", "output": "..."}
#ds=Dataset.from_pandas(df)
##ds = load_dataset("json", data_files="Finetuning/[SFT]luxbeau5reason_sft_dataset_lbr.jsonl", split="train")
#tokenizer = AutoTokenizer.from_pretrained(repo_id, use_fast=False)
#tokenizer.pad_token = tokenizer.eos_token
#
## 5) Tokenize + prepare labels
#def tokenize_fn(example):
#    # join input+output so that model learns to generate "output"
#    full = example["input"] + " " + example["output"]
#    tokenized = tokenizer(
#        full,
#        truncation=True,
#        padding="longest",
#        max_length=512,
#    )
#    # mask input tokens in labels
#    inp_len = len(tokenizer(example["input"], add_special_tokens=False)["input_ids"])
#    labels = tokenized["input_ids"].copy()
#    #labels[:inp_len] = -100
#    labels = [-100] * inp_len + labels[inp_len:]
#    labels = labels[:512] 
#    tokenized["labels"] = labels
#    return tokenized
#
#ds = ds.map(tokenize_fn, remove_columns=["input", "output"], batched=False)
#
## 6) Define SFT training args
#sft_config = SFTConfig(
#    output_dir="/storage/[(ei_LLtot]_primepantry_full_sft_phi4_adapter",
#    per_device_train_batch_size=8,
#    gradient_accumulation_steps=8,
#    num_train_epochs=17,
#    learning_rate=2e-4,
#    logging_steps=50,
#    save_strategy="steps",
#    save_steps=100,
#    save_total_limit=1,
#    fp16=True,
#    optim="paged_adamw_32bit",
#)
#
#
#
#
#trainer = SFTTrainer(
#    model=model,
#    train_dataset=ds,
#    peft_config=peft_config,
#    
#    callbacks=[PrintDebugCallback()],
#    args=sft_config,
#)
#
## 7) Train
#trainer.train(resume_from_checkpoint=True)
#
## 8) Save final adapter & tokenizer
#model.save_pretrained("[e15-lltot]_primepantry_full_sft_phi4_adapter")
#tokenizer.save_pretrained("[e15-lltot]_primepantry_full_sft_phi4_adapter")
#
## 9) Inference Example
##model.eval()
##prompt = "User interacted with: item_1, item_2. Candidates: item_3, item_4. Reason: likes action."
##inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
##generation = model.generate(
##    **inputs,
##    max_new_tokens=16,
##    do_sample=False,
##)
##print(tokenizer.decode(generation[0], skip_special_tokens=True))
#
##output_path = "Finetuning/predictions.txt"
##
##model.eval()
##with open(output_path, "w") as f:
##    for example in ds:  # ds is your dataset with "input" and "output" fields
##        prompt = example["input"]
##        label = example["output"]
##
##        inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
##        generation = model.generate(
##            **inputs,
##            max_new_tokens=3,
##            do_sample=False,
##            eos_token_id=tokenizer.eos_token_id,
##        )
##
##        # Extract generated tokens beyond input tokens
##        gen_tokens = generation[0][inputs["input_ids"].shape[-1] :]
##        predicted = tokenizer.decode(gen_tokens, skip_special_tokens=True).strip()
##
##        # Write to file
##        f.write(f"{prompt}\n")
##        f.write(f"Answer: {label}\n")
##        f.write(f"llm: {predicted}\n\n")
#


import os
import torch
import pandas as pd
from datasets import Dataset
from peft import get_peft_model, LoraConfig, prepare_model_for_kbit_training
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from trl import SFTConfig, SFTTrainer
from transformers import TrainerCallback
import matplotlib.pyplot as plt
import numpy as np
import json

# -----------------------------
# 1) Environment and quantization
# -----------------------------
os.environ["NCCL_IB_DISABLE"] = "1"
os.environ["NCCL_P2P_DISABLE"] = "1"

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True,
    bnb_4bit_compute_dtype=torch.float16,
)

# -----------------------------
# 2) Load dataset
# -----------------------------
df = pd.read_json("/storage/Pervez/normal_run_1_5/[Sbert_ablat]train_vidgames_full.json", lines=True)
ds = Dataset.from_pandas(df)

# -----------------------------
# 3) Load pretrained LLM
# -----------------------------
repo_id = "microsoft/Phi-4-mini-instruct"
model = AutoModelForCausalLM.from_pretrained(
    repo_id,
    device_map="auto",
    quantization_config=bnb_config,
)
model = prepare_model_for_kbit_training(model)

# -----------------------------
# 4) LoRA Adapter
# -----------------------------
peft_config = LoraConfig(
    r=8,
    lora_alpha=16,
    target_modules=["o_proj", "qkv_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM",
)
model = get_peft_model(model, peft_config)

# -----------------------------
# 5) Tokenizer + Tokenization
# -----------------------------
tokenizer = AutoTokenizer.from_pretrained(repo_id, use_fast=False)
tokenizer.pad_token = tokenizer.eos_token

def tokenize_fn(example):
    full = example["input"] + " " + example["output"]
    tokenized = tokenizer(full, truncation=True, padding="longest", max_length=512)
    inp_len = len(tokenizer(example["input"], add_special_tokens=False)["input_ids"])
    labels = [-100] * inp_len + tokenized["input_ids"][inp_len:]
    tokenized["labels"] = labels[:512]
    return tokenized

ds = ds.map(tokenize_fn, remove_columns=["input", "output"], batched=False)

# -----------------------------
# 6) SFT Training config
# -----------------------------
sft_config = SFTConfig(
    output_dir="/storage/[Sbert_abalt]_videogames_sft_phi4_adapter",
    per_device_train_batch_size=8,
    gradient_accumulation_steps=8,
    num_train_epochs=7,
    learning_rate=2e-4,
    logging_steps=50,
    save_strategy="steps",
    save_steps=100,
    save_total_limit=1,
    fp16=True,
    optim="paged_adamw_32bit",
)

# -----------------------------
# 7) Callback to log loss and token accuracy
# -----------------------------
import math
from transformers import TrainerCallback

class MetricsLoggerCallback(TrainerCallback):
    def __init__(self):
        self.metrics = {"epochs": [], "losses": [], "mean_token_acc": []}

    def on_log(self, args, state, control, logs=None, **kwargs):
        if logs and "loss" in logs and "epoch" in logs:
            self.metrics["epochs"].append(logs["epoch"])
            self.metrics["losses"].append(logs["loss"])
            # Use math.exp for float
            self.metrics["mean_token_acc"].append(float(math.exp(-logs["loss"])))
        return control


metrics_logger = MetricsLoggerCallback()

# -----------------------------
# 8) Trainer
# -----------------------------
trainer = SFTTrainer(
    model=model,
    train_dataset=ds,
    peft_config=peft_config,
    args=sft_config,
    callbacks=[metrics_logger],
)

# -----------------------------
# 9) Train
# -----------------------------
trainer.train(resume_from_checkpoint=False)

# -----------------------------
# 10) Save adapter & tokenizer
# -----------------------------
model.save_pretrained(sft_config.output_dir)
tokenizer.save_pretrained(sft_config.output_dir)

# -----------------------------
# 11) Save metrics to JSON
# -----------------------------
metrics_file = os.path.join(sft_config.output_dir, "metrics_log.json")
with open(metrics_file, "w") as f:
    json.dump(metrics_logger.metrics, f, indent=4)

# -----------------------------
# 12) Plot Epoch vs Loss
# -----------------------------
unique_epochs = sorted(set(metrics_logger.metrics["epochs"]))
avg_losses = [
    np.mean([metrics_logger.metrics["losses"][i] for i, e in enumerate(metrics_logger.metrics["epochs"]) if e == ue])
    for ue in unique_epochs
]

plt.figure(figsize=(8,5))
plt.plot(unique_epochs, avg_losses, marker='o')
plt.xlabel("Epoch")
plt.ylabel("Average Loss")
plt.title("Training Loss vs Epoch")
plt.grid(True)
plt.savefig(os.path.join(sft_config.output_dir, "loss_vs_epoch.png"))
plt.close()

# -----------------------------
# 13) Plot Epoch vs Mean Token Accuracy
# -----------------------------
avg_acc = [
    np.mean([metrics_logger.metrics["mean_token_acc"][i] for i, e in enumerate(metrics_logger.metrics["epochs"]) if e == ue])
    for ue in unique_epochs
]

plt.figure(figsize=(8,5))
plt.plot(unique_epochs, avg_acc, marker='o', color='green')
plt.xlabel("Epoch")
plt.ylabel("Mean Token Accuracy")
plt.title("Mean Token Accuracy vs Epoch")
plt.grid(True)
plt.savefig(os.path.join(sft_config.output_dir, "mean_token_acc_vs_epoch.png"))
plt.close()
