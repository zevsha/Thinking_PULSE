#import json
#import torch
#from transformers import AutoTokenizer, AutoModel
#from tqdm import tqdm
#import numpy as np
#from sklearn.manifold import TSNE
#from sklearn.metrics.pairwise import cosine_similarity
#import matplotlib.pyplot as plt
#import random
#import textwrap
#
## --- 0. SETUP: Model ---
#class ThoughtEncoder(torch.nn.Module):
#    def __init__(self, model_name="distilbert-base-uncased"):
#        super(ThoughtEncoder, self).__init__()
#        self.transformer = AutoModel.from_pretrained(model_name)
#
#    def forward(self, input_ids, attention_mask):
#        outputs = self.transformer(input_ids=input_ids, attention_mask=attention_mask)
#        return outputs.last_hidden_state[:, 0]  # CLS embedding
#
#
#def load_trained_models(rationale_path, behavior_path, device):
#    rationale_encoder = ThoughtEncoder().to(device)
#    behavior_encoder = ThoughtEncoder().to(device)
#    rationale_encoder.load_state_dict(torch.load(rationale_path, map_location=device))
#    behavior_encoder.load_state_dict(torch.load(behavior_path, map_location=device))
#    rationale_encoder.eval()
#    behavior_encoder.eval()
#    return rationale_encoder, behavior_encoder
#
#
## --- Utility: wrap & truncate text so boxes remain neat ---
#def wrap_and_truncate(text, width=40, max_lines=6, max_chars=400):
#    """
#    Wrap text to `width` characters per line, truncate to `max_chars`,
#    and limit to `max_lines` lines. Returns the formatted string.
#    """
#    if text is None:
#        return ""
#    text = text.strip().replace("\n", " ")
#    if len(text) > max_chars:
#        text = text[:max_chars].rstrip() + "…"
#    wrapped = textwrap.fill(text, width=width)
#    # limit to max_lines
#    lines = wrapped.splitlines()
#    if len(lines) > max_lines:
#        lines = lines[:max_lines]
#        lines[-1] = lines[-1].rstrip() + " …"
#    return "\n".join(lines)
#
#
## --- 1. Generate vectors with negatives (non-overlapping) ---
#def generate_vectors_with_negatives(R_encoder, B_encoder, tokenizer,
#                                   pos_users, neg_users,
#                                   device, max_length=256, sample_negatives=1):
#   pos_rationale_vecs, behavior_vecs, neg_rationale_vecs = [], [], []
#   pos_texts, beh_texts, neg_texts = [], [], []
#   # keep mapping: which negatives belong to which user
#   user_neg_indices = []
#   sampled_negs = random.sample(neg_users, sample_negatives)
#   neg_idx_list = []
#   R_encoder.eval()
#   B_encoder.eval()
#   with torch.no_grad():
#       for idx, item in enumerate(tqdm(pos_users, desc="Encoding Positives + Behaviors")):
#           # Positive rationale
#           rationale_text = item.get('reason', '')
#           tok_rationale = tokenizer(rationale_text, max_length=max_length,
#                                     padding='max_length', truncation=True,
#                                     return_tensors='pt').to(device)
#           vec_pos = R_encoder(**tok_rationale).cpu().numpy()
#           pos_rationale_vecs.append(vec_pos)
#           pos_texts.append(rationale_text)
#           # Behavior
#           behavior_context = f"[CONTEXT] History: {item.get('item','')} [CHOSEN_ITEM] {item.get('answer','')}"
#           tok_behavior = tokenizer(behavior_context, max_length=max_length,
#                                    padding='max_length', truncation=True,
#                                    return_tensors='pt').to(device)
#           vec_bhv = B_encoder(**tok_behavior).cpu().numpy()
#           behavior_vecs.append(vec_bhv)
#           beh_texts.append(behavior_context)
#        # --- Sample negatives for THIS user only ---
#        
#       for neg_item in sampled_negs:
#            neg_text = neg_item.get('reason', '')
#            tok_neg = tokenizer(neg_text, max_length=max_length,
#                                padding='max_length', truncation=True,
#                                return_tensors='pt').to(device)
#            vec_neg = R_encoder(**tok_neg).cpu().numpy()
#            neg_rationale_vecs.append(vec_neg)
#            neg_texts.append(neg_text)
#            neg_idx_list.append(len(neg_rationale_vecs) - 1)  # store index
#       user_neg_indices.append(neg_idx_list)
#   # Convert to numpy
#   pos_rationale_vecs = np.concatenate(pos_rationale_vecs, axis=0)
#   behavior_vecs = np.concatenate(behavior_vecs, axis=0)
#   neg_rationale_vecs = np.concatenate(neg_rationale_vecs, axis=0) if len(neg_rationale_vecs) > 0 else np.zeros((0, pos_rationale_vecs.shape[1]))
#   labels = (["Positive Rationale"] * len(pos_rationale_vecs) +
#             ["Behavior Context"] * len(behavior_vecs) +
#             ["Negative Rationale"] * len(neg_rationale_vecs))
#   all_vecs = np.concatenate([pos_rationale_vecs, behavior_vecs, neg_rationale_vecs], axis=0) if len(neg_rationale_vecs) > 0 else np.concatenate([pos_rationale_vecs, behavior_vecs], axis=0)
#   return all_vecs, labels, pos_rationale_vecs, behavior_vecs, neg_rationale_vecs, pos_texts, beh_texts, neg_texts, user_neg_indices
#
## --- 2. t-SNE ---
#def run_tsne(vectors, perplexity=30):
#    tsne = TSNE(n_components=2, verbose=1, perplexity=perplexity, max_iter=1000, random_state=42, init="pca")
#    return tsne.fit_transform(vectors)
#
#def clean_for_display(text):
#    if text.strip().startswith("####"):
#        # remove the prefix `{'rationale': '` and trailing `'}`
#        text = text.strip()[37:-2]  
#    return text
#
#
## --- 3. Plot with mapping + neat annotations ---
#def plot_space_with_mapping(vectors_2d, labels, pos_vecs, beh_vecs, neg_vecs,
#                            pos_texts, beh_texts,user_neg_indices,
#                            title, filename, max_lines=10, annotate_first_n=1,
#                            wrap_width=50, wrap_lines=7, font_size=8):
#    """
#    - max_lines: how many mapping lines to draw (controls clutter)
#    - annotate_first_n: how many of the first examples to annotate (1 by default)
#    """
#    print("Plotting with mapping:", title)
#    fig, ax = plt.subplots(figsize=(10, 10))
#
#    # Nice aesthetics for paper
#    plt.rcParams.update({'font.size': font_size})
#    colors = {
#        'Positive Rationale': '#1f77b4',  # blue
#        'Negative Rationale': '#d62728',  # red
#        'Behavior Context': '#2ca02c'     # green
#    }
#
#    # Separate points by type
#    pos_idx = [i for i, l in enumerate(labels) if l == "Positive Rationale"]
#    beh_idx = [i for i, l in enumerate(labels) if l == "Behavior Context"]
#    neg_idx = [i for i, l in enumerate(labels) if l == "Negative Rationale"]
#
#    pos_points = vectors_2d[pos_idx]
#    beh_points = vectors_2d[beh_idx]
#    neg_points = vectors_2d[neg_idx] if len(neg_idx) > 0 else np.zeros((0,2))
#
#    # Smaller markers
#    ax.scatter(pos_points[:, 0], pos_points[:, 1],
#               c=colors["Positive Rationale"], label="Positive Rationale", alpha=0.85, s=40, edgecolors='k', lw=0.2)
#    ax.scatter(beh_points[:, 0], beh_points[:, 1],
#               c=colors["Behavior Context"], label="Behavior Context", alpha=0.9, s=50, edgecolors='k', lw=0.2)
#    if len(neg_points) > 0:
#        ax.scatter(neg_points[:, 0], neg_points[:, 1],
#                   c=colors["Negative Rationale"], label="Negative Rationale", alpha=0.7, s=35)
#
#    # Mapping lines (limit to reduce clutter)
#    line_indices = list(range(min(max_lines, len(beh_points))))
#    for i in line_indices:
#        ax.plot([beh_points[i, 0], pos_points[i, 0]],
#                [beh_points[i, 1], pos_points[i, 1]], '-', color='tab:blue', alpha=0.45, linewidth=0.9)
#
#    # Behavior -> farthest negative (if available), compute on original embeddings (neg_vecs)
#    #if len(neg_vecs) > 0:
#    #    sim_matrix = cosine_similarity(beh_vecs, neg_vecs)
#    #    farthest_neg_idx = np.argmin(sim_matrix, axis=1)
#    #    for i in line_indices:
#    #        j = farthest_neg_idx[i]
#    #        # make sure j is within neg_points
#    #        if j < len(neg_points):
#    #            ax.plot([beh_points[i, 0], neg_points[j, 0]],
#    #                    [beh_points[i, 1], neg_points[j, 1]], '--', color='tab:red', alpha=0.45, linewidth=0.9)
#            # Behavior → its OWN farthest negative
#    if len(user_neg_indices[i]) > 0:
#        user_neg_vecs = neg_vecs[user_neg_indices[i]]
#        sims = cosine_similarity(beh_vecs[i:i+1], user_neg_vecs)[0]
#        farthest_idx = np.argmin(sims)
#        j = user_neg_indices[i][farthest_idx]
#        ax.plot([beh_points[i, 0], neg_points[j, 0]],
#                [beh_points[i, 1], neg_points[j, 1]], '--', color='tab:red', alpha=0.45, linewidth=0.9)
#
#
#
#    # --- Annotate the first N examples with neat boxed labels + arrow ---
#    for idx in range(min(annotate_first_n, len(beh_points))):
#        bx, by = beh_points[idx]
#        px, py = pos_points[idx]
#
#        # print full texts in console so you can keep a record (and craft short labels if desired)
#        print(f"\n=== Example {idx+1} (console output) ===")
#        print("BEHAVIOR full text:\n", beh_texts[idx])
#        print("\nRATIONALE full text:\n", pos_texts[idx])
#        print("======================================\n")
#
#        # Prepare short neat display text by wrapping/truncating
#        #beh_display = wrap_and_truncate(beh_texts[idx], width=wrap_width, max_lines=wrap_lines)
#        #pos_display = wrap_and_truncate(pos_texts[idx], width=wrap_width, max_lines=wrap_lines)
#
#        # If you prefer manual short labels, replace beh_display / pos_display here:
#        #beh_display = "[CONTEXT] History: ['Pure Protein 23 Grams, Vanilla Creme (4 Count, 12 Fl Oz Each)', 'Corn Nuts Snack Mix, Chile Picante Flavor, 7 Ounce Bag'] [CHOSEN_ITEM] Red Bull Energy Drink Sugar Free 4 Pack of 8.4 Fl Oz, Sugarfree"
#        #pos_display = "The user's preferences indicate a focus on convenience, health, and flavor. They chose a sugar-free energy drink likely for its health benefits and to align with a preference for products that serve as meal replacements or snacks with significant nutritional value, similar to the pure protein shake, but tailored for energy needs."
#        
#        beh_display = wrap_and_truncate(clean_for_display(beh_texts[idx]), width=wrap_width, max_lines=wrap_lines)
#        pos_display = wrap_and_truncate(clean_for_display(pos_texts[idx]), width=wrap_width, max_lines=wrap_lines)
#
#        # Behavior box (placed to the top-right with arrow)
#        ax.annotate(beh_display,
#                    xy=(bx, by),
#                    xytext=(40, 30), textcoords='offset points',
#                    fontsize=font_size, ha='left', va='bottom',
#                    bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="0.2", lw=0.6, alpha=0.95),
#                    arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=0.15", color="gray", lw=0.6))
#
#        # Rationale box (placed below-right with arrow)
#        ax.annotate(pos_display,
#                    xy=(px, py),
#                    xytext=(40, -50), textcoords='offset points',
#                    fontsize=font_size, ha='left', va='top',
#                    bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="0.2", lw=0.6, alpha=0.95),
#                    arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=-0.15", color="gray", lw=0.6))
#
#    # Clean up axes for publication look
#    ax.set_title(title, fontsize=12)
#    ax.set_xlabel("t-SNE Dim 1", fontsize=10)
#    ax.set_ylabel("t-SNE Dim 2", fontsize=10)
#    ax.grid(True, linestyle='--', alpha=0.25)
#    ax.legend(frameon=False, fontsize=9)
#
#    plt.tight_layout()
#    # Save high-res PNG + vector PDF (use PDF for paper submissions)
#    plt.savefig(filename + ".png", dpi=300, bbox_inches='tight')
#    plt.savefig(filename + ".pdf", bbox_inches='tight')  # vector
#    print(f"Saved {filename}.png and {filename}.pdf")
#    plt.show()
#
#
## --- 4. Main ---
#if __name__ == "__main__":
#    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
#    NUM_POS_USERS = 157
#    SAMPLE_NEGATIVES = 1
#
#    RATIONALE_ENCODER_PATH = "/storage/SFTrecc/[53e_onlyphi_10n_9k]rationale_encoder.pth"
#    BEHAVIOR_ENCODER_PATH = "/storage/SFTrecc/[53e_onlyphi_10n_9k]behavior_encoder.pth"
#    RATIONALES_FILE_PATH = "/storage/Pervez/[onlyphi_9k]thought_spacedata.json"
#
#    # Load data
#    with open(RATIONALES_FILE_PATH, 'r') as f:
#        full_data = json.load(f)
#
#    pos_users = full_data[:NUM_POS_USERS]
#    neg_users = full_data[NUM_POS_USERS:373]  # disjoint set
#
#    tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
#
#    # --- Before training ---
#    print("\n--- Before Training ---")
#    R_encoder_raw = ThoughtEncoder().to(DEVICE)
#    B_encoder_raw = ThoughtEncoder().to(DEVICE)
#
#    all_vecs, labels, pos_vecs, beh_vecs, neg_vecs, pos_texts, beh_texts, neg_texts,user_neg_indices = generate_vectors_with_negatives(
#        R_encoder_raw, B_encoder_raw, tokenizer, pos_users, neg_users,
#        DEVICE, sample_negatives=SAMPLE_NEGATIVES
#    )
#    perplexity = min(30, max(5, len(all_vecs) - 1))  # safe lower bound
#    vecs_2d = run_tsne(all_vecs, perplexity=perplexity)
#    plot_space_with_mapping(vecs_2d, labels, pos_vecs, beh_vecs, neg_vecs,
#                            pos_texts, beh_texts,user_neg_indices,
#                            "Thought Space Mapping (Before Training)",
#                            "2thought_space_before_mapping_neat",
#                            max_lines=13, annotate_first_n=1,
#                            wrap_width=40, wrap_lines=7, font_size=8)
#
#    # --- After training ---
#    print("\n--- After Training ---")
#    R_encoder_trained, B_encoder_trained = load_trained_models(RATIONALE_ENCODER_PATH,
#                                                               BEHAVIOR_ENCODER_PATH, DEVICE)
#
#    all_vecs, labels, pos_vecs, beh_vecs, neg_vecs, pos_texts, beh_texts, neg_texts,user_neg_indices = generate_vectors_with_negatives(
#        R_encoder_trained, B_encoder_trained, tokenizer, pos_users, neg_users,
#        DEVICE, sample_negatives=SAMPLE_NEGATIVES
#    )
#    perplexity = min(30, max(5, len(all_vecs) - 1))
#    vecs_2d = run_tsne(all_vecs, perplexity=perplexity)
#    plot_space_with_mapping(vecs_2d, labels, pos_vecs, beh_vecs, neg_vecs,
#                            pos_texts, beh_texts,user_neg_indices,
#                            "Thought Space Mapping (After Training)",
#                            "2thought_space_after_mapping_neat",
#                            max_lines=13, annotate_first_n=1,
#                            wrap_width=40, wrap_lines=7, font_size=8)


#import json
#import torch
#from transformers import AutoTokenizer, AutoModel
#from tqdm import tqdm
#import numpy as np
#from sklearn.manifold import TSNE
#from sklearn.metrics.pairwise import cosine_similarity
#import matplotlib.pyplot as plt
#import random
#import textwrap
#
## --- 0. SETUP: Model ---
#class ThoughtEncoder(torch.nn.Module):
#    def __init__(self, model_name="distilbert-base-uncased"):
#        super(ThoughtEncoder, self).__init__()
#        self.transformer = AutoModel.from_pretrained(model_name)
#
#    def forward(self, input_ids, attention_mask):
#        outputs = self.transformer(input_ids=input_ids, attention_mask=attention_mask)
#        return outputs.last_hidden_state[:, 0]  # CLS embedding
#
#
#def load_trained_models(rationale_path, behavior_path, device):
#    rationale_encoder = ThoughtEncoder().to(device)
#    behavior_encoder = ThoughtEncoder().to(device)
#    rationale_encoder.load_state_dict(torch.load(rationale_path, map_location=device))
#    behavior_encoder.load_state_dict(torch.load(behavior_path, map_location=device))
#    rationale_encoder.eval()
#    behavior_encoder.eval()
#    return rationale_encoder, behavior_encoder
#
#
## --- Utility: wrap & truncate text ---
#def wrap_and_truncate(text, width=40, max_lines=6, max_chars=400):
#    if text is None:
#        return ""
#    text = text.strip().replace("\n", " ")
#    if len(text) > max_chars:
#        text = text[:max_chars].rstrip() + "…"
#    wrapped = textwrap.fill(text, width=width)
#    lines = wrapped.splitlines()
#    if len(lines) > max_lines:
#        lines = lines[:max_lines]
#        lines[-1] = lines[-1].rstrip() + " …"
#    return "\n".join(lines)
#
#
## --- 1. Generate vectors with negatives (per-user sampling) ---
#def generate_vectors_with_negatives(R_encoder, B_encoder, tokenizer,
#                                    pos_users, neg_users,
#                                    device, max_length=256, sample_negatives=1):
#    pos_rationale_vecs, behavior_vecs, neg_rationale_vecs = [], [], []
#    pos_texts, beh_texts, neg_texts = [], [], []
#
#    # keep mapping: which negatives belong to which user
#    user_neg_indices = []
#
#    R_encoder.eval()
#    B_encoder.eval()
#
#    with torch.no_grad():
#        for idx, item in enumerate(tqdm(pos_users, desc="Encoding Positives + Behaviors")):
#            # Positive rationale
#            rationale_text = item.get('reason', '')
#            tok_rationale = tokenizer(rationale_text, max_length=max_length,
#                                      padding='max_length', truncation=True,
#                                      return_tensors='pt').to(device)
#            vec_pos = R_encoder(**tok_rationale).cpu().numpy()
#            pos_rationale_vecs.append(vec_pos)
#            pos_texts.append(rationale_text)
#
#            # Behavior
#            behavior_context = f"[CONTEXT] History: {item.get('item','')} [CHOSEN_ITEM] {item.get('answer','')}"
#            tok_behavior = tokenizer(behavior_context, max_length=max_length,
#                                     padding='max_length', truncation=True,
#                                     return_tensors='pt').to(device)
#            vec_bhv = B_encoder(**tok_behavior).cpu().numpy()
#            behavior_vecs.append(vec_bhv)
#            beh_texts.append(behavior_context)
#
#            # --- Sample negatives for THIS user only ---
#            sampled_negs = random.sample(neg_users, sample_negatives)
#            neg_idx_list = []
#            for neg_item in sampled_negs:
#                neg_text = neg_item.get('reason', '')
#                tok_neg = tokenizer(neg_text, max_length=max_length,
#                                    padding='max_length', truncation=True,
#                                    return_tensors='pt').to(device)
#                vec_neg = R_encoder(**tok_neg).cpu().numpy()
#                neg_rationale_vecs.append(vec_neg)
#                neg_texts.append(neg_text)
#                neg_idx_list.append(len(neg_rationale_vecs) - 1)  # store index
#            user_neg_indices.append(neg_idx_list)
#
#    # Convert to numpy
#    pos_rationale_vecs = np.concatenate(pos_rationale_vecs, axis=0)
#    behavior_vecs = np.concatenate(behavior_vecs, axis=0)
#    neg_rationale_vecs = np.concatenate(neg_rationale_vecs, axis=0) if len(neg_rationale_vecs) > 0 else np.zeros((0, pos_rationale_vecs.shape[1]))
#
#    labels = (["Positive Rationale"] * len(pos_rationale_vecs) +
#              ["Behavior Context"] * len(behavior_vecs) +
#              ["Negative Rationale"] * len(neg_rationale_vecs))
#
#    all_vecs = np.concatenate([pos_rationale_vecs, behavior_vecs, neg_rationale_vecs], axis=0) if len(neg_rationale_vecs) > 0 else np.concatenate([pos_rationale_vecs, behavior_vecs], axis=0)
#
#    return all_vecs, labels, pos_rationale_vecs, behavior_vecs, neg_rationale_vecs, pos_texts, beh_texts, neg_texts, user_neg_indices
#
#
## --- 2. t-SNE ---
#def run_tsne(vectors, perplexity=30):
#    tsne = TSNE(n_components=2, verbose=1, perplexity=perplexity,
#                max_iter=1000, random_state=42, init="pca")
#    return tsne.fit_transform(vectors)
#
#
## --- 3. Plot ---
#def plot_space_with_mapping(vectors_2d, labels,
#                            pos_vecs, beh_vecs, neg_vecs,
#                            pos_texts, beh_texts, user_neg_indices,
#                            title, filename, max_lines=10, annotate_first_n=1,
#                            wrap_width=50, wrap_lines=7, font_size=8):
#    print("Plotting with mapping:", title)
#    fig, ax = plt.subplots(figsize=(10, 10))
#    plt.rcParams.update({'font.size': font_size})
#
#    colors = {
#        'Positive Rationale': '#1f77b4',  # blue
#        'Negative Rationale': '#d62728',  # red
#        'Behavior Context': '#2ca02c'     # green
#    }
#
#    # Separate points
#    pos_idx = [i for i, l in enumerate(labels) if l == "Positive Rationale"]
#    beh_idx = [i for i, l in enumerate(labels) if l == "Behavior Context"]
#    neg_idx = [i for i, l in enumerate(labels) if l == "Negative Rationale"]
#
#    pos_points = vectors_2d[pos_idx]
#    beh_points = vectors_2d[beh_idx]
#    neg_points = vectors_2d[neg_idx] if len(neg_idx) > 0 else np.zeros((0, 2))
#
#    # Scatter plot
#    ax.scatter(pos_points[:, 0], pos_points[:, 1], c=colors["Positive Rationale"],
#               label="Positive Rationale", alpha=0.85, s=40, edgecolors='k', lw=0.2)
#    ax.scatter(beh_points[:, 0], beh_points[:, 1], c=colors["Behavior Context"],
#               label="Behavior Context", alpha=0.9, s=50, edgecolors='k', lw=0.2)
#    if len(neg_points) > 0:
#        ax.scatter(neg_points[:, 0], neg_points[:, 1], c=colors["Negative Rationale"],
#                   label="Negative Rationale", alpha=0.7, s=35)
#
#    # Draw mapping lines
#    line_indices = list(range(min(max_lines, len(beh_points))))
#    for i in line_indices:
#        # Behavior → Positive
#        ax.plot([beh_points[i, 0], pos_points[i, 0]],
#                [beh_points[i, 1], pos_points[i, 1]], '-', color='tab:blue', alpha=0.45, linewidth=0.9)
#
#        # Behavior → its OWN farthest negative
#        if len(user_neg_indices[i]) > 0:
#            user_neg_vecs = neg_vecs[user_neg_indices[i]]
#            sims = cosine_similarity(beh_vecs[i:i+1], user_neg_vecs)[0]
#            farthest_idx = np.argmin(sims)
#            j = user_neg_indices[i][farthest_idx]
#            ax.plot([beh_points[i, 0], neg_points[j, 0]],
#                    [beh_points[i, 1], neg_points[j, 1]], '--', color='tab:red', alpha=0.45, linewidth=0.9)
#
#    ax.set_title(title, fontsize=12)
#    ax.set_xlabel("t-SNE Dim 1", fontsize=10)
#    ax.set_ylabel("t-SNE Dim 2", fontsize=10)
#    ax.grid(True, linestyle='--', alpha=0.25)
#    ax.legend(frameon=False, fontsize=9)
#
#    plt.tight_layout()
#    plt.savefig(filename + ".png", dpi=300, bbox_inches='tight')
#    plt.savefig(filename + ".pdf", bbox_inches='tight')
#    plt.show()
#
#
## --- 4. Main ---
#if __name__ == "__main__":
#    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
#    NUM_POS_USERS = 137
#    SAMPLE_NEGATIVES = 3  # each user gets 3 negatives
#
#    RATIONALE_ENCODER_PATH = "/storage/SFTrecc/[53e_onlyphi_10n_9k]rationale_encoder.pth"
#    BEHAVIOR_ENCODER_PATH = "/storage/SFTrecc/[53e_onlyphi_10n_9k]behavior_encoder.pth"
#    RATIONALES_FILE_PATH = "/storage/Pervez/[onlyphi_9k]thought_spacedata.json"
#
#    with open(RATIONALES_FILE_PATH, 'r') as f:
#        full_data = json.load(f)
#
#    pos_users = full_data[:NUM_POS_USERS]
#    neg_users = full_data[NUM_POS_USERS:773]
#
#    tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
#
#    # Before training
#    print("\n--- Before Training ---")
#    R_encoder_raw = ThoughtEncoder().to(DEVICE)
#    B_encoder_raw = ThoughtEncoder().to(DEVICE)
#
#    all_vecs, labels, pos_vecs, beh_vecs, neg_vecs, pos_texts, beh_texts, neg_texts, user_neg_indices = generate_vectors_with_negatives(
#        R_encoder_raw, B_encoder_raw, tokenizer, pos_users, neg_users,
#        DEVICE, sample_negatives=SAMPLE_NEGATIVES
#    )
#    perplexity = min(30, max(5, len(all_vecs) - 1))
#    vecs_2d = run_tsne(all_vecs, perplexity=perplexity)
#    plot_space_with_mapping(vecs_2d, labels, pos_vecs, beh_vecs, neg_vecs,
#                            pos_texts, beh_texts, user_neg_indices,
#                            "Thought Space Mapping (Before Training)",
#                            "t2hought_space_before_mapping")
#
#    # After training
#    print("\n--- After Training ---")
#    R_encoder_trained, B_encoder_trained = load_trained_models(RATIONALE_ENCODER_PATH,
#                                                               BEHAVIOR_ENCODER_PATH, DEVICE)
#    all_vecs, labels, pos_vecs, beh_vecs, neg_vecs, pos_texts, beh_texts, neg_texts, user_neg_indices = generate_vectors_with_negatives(
#        R_encoder_trained, B_encoder_trained, tokenizer, pos_users, neg_users,
#        DEVICE, sample_negatives=SAMPLE_NEGATIVES
#    )
#    perplexity = min(30, max(5, len(all_vecs) - 1))
#    vecs_2d = run_tsne(all_vecs, perplexity=perplexity)
#    plot_space_with_mapping(vecs_2d, labels, pos_vecs, beh_vecs, neg_vecs,
#                            pos_texts, beh_texts, user_neg_indices,
#                            "Thought Space Mapping (After Training)",
#                            "t2hought_space_after_mapping")
#

#import json
#import torch
#from transformers import AutoTokenizer, AutoModel
#from tqdm import tqdm
#import numpy as np
#from sklearn.manifold import TSNE
#from sklearn.metrics.pairwise import cosine_similarity
#import matplotlib.pyplot as plt
#import random
#import textwrap
#
## --- 0. SETUP: Model ---
#class ThoughtEncoder(torch.nn.Module):
#    def __init__(self, model_name="distilbert-base-uncased"):
#        super(ThoughtEncoder, self).__init__()
#        self.transformer = AutoModel.from_pretrained(model_name)
#
#    def forward(self, input_ids, attention_mask):
#        outputs = self.transformer(input_ids=input_ids, attention_mask=attention_mask)
#        return outputs.last_hidden_state[:, 0]  # CLS embedding
#
#
#def load_trained_models(rationale_path, behavior_path, device):
#    rationale_encoder = ThoughtEncoder().to(device)
#    behavior_encoder = ThoughtEncoder().to(device)
#    rationale_encoder.load_state_dict(torch.load(rationale_path, map_location=device))
#    behavior_encoder.load_state_dict(torch.load(behavior_path, map_location=device))
#    rationale_encoder.eval()
#    behavior_encoder.eval()
#    return rationale_encoder, behavior_encoder
#
#
## --- Utility: wrap & truncate text so boxes remain neat ---
#def wrap_and_truncate(text, width=40, max_lines=6, max_chars=400):
#    if text is None:
#        return ""
#    text = text.strip().replace("\n", " ")
#    if len(text) > max_chars:
#        text = text[:max_chars].rstrip() + "…"
#    wrapped = textwrap.fill(text, width=width)
#    lines = wrapped.splitlines()
#    if len(lines) > max_lines:
#        lines = lines[:max_lines]
#        lines[-1] = lines[-1].rstrip() + " …"
#    return "\n".join(lines)
#
#
#def clean_for_display(text):
#    # Simple cleanup if reason stored as small JSON-like string e.g. "{'rationale': '...'}"
#    if not isinstance(text, str):
#        return ""
#    s = text.strip()
#    if s.startswith("{") and "rationale" in s:
#        # naive extraction of value between first single-quote pairs after 'rationale':
#        import re
#        m = re.search(r"'rationale'\s*:\s*'(.+)'", s)
#        if m:
#            return m.group(1)
#    return text
#
#
## --- 1. Generate vectors with negatives (per-user sampling) ---
#def generate_vectors_with_negatives(R_encoder, B_encoder, tokenizer,
#                                    pos_users, neg_users,
#                                    device, max_length=256, sample_negatives=1,
#                                    seed=42):
#    random.seed(seed)
#    pos_rationale_vecs, behavior_vecs, neg_rationale_vecs = [], [], []
#    pos_texts, beh_texts, neg_texts = [], [], []
#
#    # mapping: for each pos-user index i -> list of indices (into neg_rationale_vecs)
#    user_neg_indices = []
#
#    R_encoder.eval()
#    B_encoder.eval()
#
#    with torch.no_grad():
#        # First encode positives & behaviours
#        for item in tqdm(pos_users, desc="Encoding Positives + Behaviors"):
#            rationale_text = item.get('reason', '')
#            rationale_text = clean_for_display(rationale_text)
#            tok_rationale = tokenizer(rationale_text, max_length=max_length,
#                                      padding='max_length', truncation=True,
#                                      return_tensors='pt').to(device)
#            vec_pos = R_encoder(**tok_rationale).cpu().numpy()
#            pos_rationale_vecs.append(vec_pos)
#            pos_texts.append(rationale_text)
#
#            behavior_context = f"[CONTEXT] History: {item.get('item','')} [CHOSEN_ITEM] {item.get('answer','')}"
#            tok_behavior = tokenizer(behavior_context, max_length=max_length,
#                                     padding='max_length', truncation=True,
#                                     return_tensors='pt').to(device)
#            vec_bhv = B_encoder(**tok_behavior).cpu().numpy()
#            behavior_vecs.append(vec_bhv)
#            beh_texts.append(behavior_context)
#
#            # Sample negatives for THIS user (from neg_users); don't remove from pool
#            k = min(sample_negatives, max(1, len(neg_users)))
#            sampled_negs = random.sample(neg_users, k) if k <= len(neg_users) else random.choices(neg_users, k=k)
#            neg_indices_for_user = []
#            for neg_item in sampled_negs:
#                neg_text = neg_item.get('reason', '')
#                neg_text = clean_for_display(neg_text)
#                tok_neg = tokenizer(neg_text, max_length=max_length,
#                                    padding='max_length', truncation=True,
#                                    return_tensors='pt').to(device)
#                vec_neg = R_encoder(**tok_neg).cpu().numpy()
#                neg_rationale_vecs.append(vec_neg)
#                neg_texts.append(neg_text)
#                neg_indices_for_user.append(len(neg_rationale_vecs) - 1)  # index into neg_rationale_vecs
#            user_neg_indices.append(neg_indices_for_user)
#
#    # Convert to numpy arrays
#    pos_rationale_vecs = np.concatenate(pos_rationale_vecs, axis=0)  # shape (N_pos, d)
#    behavior_vecs = np.concatenate(behavior_vecs, axis=0)            # shape (N_pos, d)
#    if len(neg_rationale_vecs) > 0:
#        neg_rationale_vecs = np.concatenate(neg_rationale_vecs, axis=0)  # shape (N_neg_total, d)
#    else:
#        neg_rationale_vecs = np.zeros((0, pos_rationale_vecs.shape[1]))
#
#    labels = (["Positive Rationale"] * len(pos_rationale_vecs) +
#              ["Behavior Context"] * len(behavior_vecs) +
#              ["Negative Rationale"] * len(neg_rationale_vecs))
#
#    # all vectors concatenated in same order as labels
#    if len(neg_rationale_vecs) > 0:
#        all_vecs = np.concatenate([pos_rationale_vecs, behavior_vecs, neg_rationale_vecs], axis=0)
#    else:
#        all_vecs = np.concatenate([pos_rationale_vecs, behavior_vecs], axis=0)
#
#    return all_vecs, labels, pos_rationale_vecs, behavior_vecs, neg_rationale_vecs, pos_texts, beh_texts, neg_texts, user_neg_indices
#
#
## --- 2. t-SNE ---
#def run_tsne(vectors, perplexity=30):
#    tsne = TSNE(n_components=2, verbose=1, perplexity=perplexity, max_iter=1000, random_state=42, init="pca")
#    return tsne.fit_transform(vectors)
#
#
## --- 3. Plot with mapping + neat annotations ---
#def plot_space_with_mapping(vectors_2d, labels, pos_vecs, beh_vecs, neg_vecs,
#                            pos_texts, beh_texts, neg_texts, user_neg_indices,
#                            title, filename, max_lines=10, annotate_first_n=1,
#                            wrap_width=50, wrap_lines=7, font_size=8):
#    fig, ax = plt.subplots(figsize=(10, 10))
#    plt.rcParams.update({'font.size': font_size})
#
#    colors = {
#        'Positive Rationale': '#1f77b4',  # blue
#        'Negative Rationale': '#d62728',  # red
#        'Behavior Context': '#2ca02c'     # green
#    }
#
#    # indices in concatenated vectors: pos (0..P-1), beh (P..P+B-1), neg (P+B..)
#    pos_count = len(pos_vecs)
#    beh_count = len(beh_vecs)
#    neg_count = len(neg_vecs)
#
#    pos_idx = list(range(0, pos_count))
#    beh_idx = list(range(pos_count, pos_count + beh_count))
#    neg_idx = list(range(pos_count + beh_count, pos_count + beh_count + neg_count))
#
#    # split 2D vectors
#    pos_points = vectors_2d[pos_idx]
#    beh_points = vectors_2d[beh_idx]
#    neg_points = vectors_2d[neg_idx] if neg_count > 0 else np.zeros((0, 2))
#
#    # scatter
#    ax.scatter(pos_points[:, 0], pos_points[:, 1],
#               c=colors["Positive Rationale"], label="Positive Rationale", alpha=0.85, s=40, edgecolors='k', lw=0.2)
#    ax.scatter(beh_points[:, 0], beh_points[:, 1],
#               c=colors["Behavior Context"], label="Behavior Context", alpha=0.9, s=50, edgecolors='k', lw=0.2)
#    if neg_count > 0:
#        ax.scatter(neg_points[:, 0], neg_points[:, 1],
#                   c=colors["Negative Rationale"], label="Negative Rationale", alpha=0.85, s=45)
#
#    # mapping behaviour -> positive (one-to-one)
#    line_indices = list(range(min(max_lines, beh_count)))
#    for i in line_indices:
#        ax.plot([beh_points[i, 0], pos_points[i, 0]],
#                [beh_points[i, 1], pos_points[i, 1]], '-', color='tab:blue', alpha=0.45, linewidth=0.9)
#
#    # mapping behaviour -> its own farthest negative (per-user)
#    if neg_count > 0:
#        # neg_vecs is array of shape (N_neg_total, d)
#        for i in line_indices:
#            neg_indices_for_user = user_neg_indices[i]  # indices into neg_vecs (0..N_neg_total-1)
#            if len(neg_indices_for_user) == 0:
#                continue
#            # build array of the user's negative vectors
#            user_negs = neg_vecs[neg_indices_for_user]  # shape (k, d)
#            sims = cosine_similarity(beh_vecs[i:i+1], user_negs)[0]  # (k,)
#            farthest_local_idx = int(np.argmin(sims))
#            global_neg_idx = neg_indices_for_user[farthest_local_idx]  # 0..N_neg_total-1
#            # index into neg_points array (same ordering)
#            if global_neg_idx < neg_count:
#                nx, ny = neg_points[global_neg_idx]
#                bx, by = beh_points[i]
#                ax.plot([bx, nx], [by, ny], '--', color='tab:red', alpha=0.45, linewidth=0.9)
#
#    # --- Annotate the first N examples with neat boxed labels + arrow ---
#        # --- Annotate the first N examples with neat boxed labels + arrow ---
#    for idx in range(min(annotate_first_n, beh_count)):
#        bx, by = beh_points[idx]
#        px, py = pos_points[idx]
#
#        # Console print of full texts
#        print(f"\n=== Example {idx+1} (console output) ===")
#        print("BEHAVIOR full text:\n", beh_texts[idx])
#        print("\nPOSITIVE RATIONALE full text:\n", pos_texts[idx])
#
#        # find farthest negative for this user
#        neg_display = None
#        if neg_count > 0 and len(user_neg_indices[idx]) > 0:
#            user_negs = neg_vecs[user_neg_indices[idx]]
#            sims = cosine_similarity(beh_vecs[idx:idx+1], user_negs)[0]
#            farthest_local_idx = int(np.argmin(sims))
#            global_neg_idx = user_neg_indices[idx][farthest_local_idx]
#            nx, ny = neg_points[global_neg_idx]
#
#            neg_display = wrap_and_truncate(neg_texts[global_neg_idx][43:], width=wrap_width, max_lines=wrap_lines)
#            print("\nNEGATIVE RATIONALE full text:\n", neg_texts[global_neg_idx])
#
#        print("======================================\n")
#
#        beh_display = wrap_and_truncate(beh_texts[idx], width=wrap_width, max_lines=wrap_lines)
#        pos_display = wrap_and_truncate(pos_texts[idx], width=wrap_width, max_lines=wrap_lines)
#        
#        #neg_display=neg_texts[global_neg_idx][299:]
#
#        # offsets (tune to taste)
#        bx_off, by_off = (-79, 50)
#        px_off, py_off = (40, -80)
#        nx_off, ny_off = (210, 30)
#
#        # Behavior box
#        ax.annotate(beh_display,
#                    xy=(bx, by),
#                    xytext=(bx_off, by_off), textcoords='offset points',
#                    fontsize=font_size, ha='left', va='bottom',
#                    bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="0.2", lw=0.6, alpha=0.95),
#                    arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=0.15", color="gray", lw=0.6))
#
#        # Positive rationale box
#        ax.annotate(pos_display[37:-2],
#                    xy=(px, py),
#                    xytext=(px_off, py_off), textcoords='offset points',
#                    fontsize=font_size, ha='left', va='top',
#                    bbox=dict(boxstyle="round,pad=0.3", fc="lightblue", ec="0.2", lw=0.6, alpha=0.95),
#                    arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=-0.15", color="gray", lw=0.6))
#
#        # Negative rationale box (if exists)
#        if neg_display:
#            ax.annotate(neg_display,
#                        xy=(nx, ny),
#                        xytext=(nx_off, ny_off), textcoords='offset points',
#                        fontsize=font_size, ha='right', va='top',
#                        bbox=dict(boxstyle="round,pad=0.3", fc="#f4cccc", ec="0.2", lw=0.6, alpha=0.95),
#                        arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=0.1", color="gray", lw=0.6))
#
#
#    # publication-style finishing
#    ax.set_title(title, fontsize=12)
#    ax.set_xlabel("t-SNE Dim 1", fontsize=10)
#    ax.set_ylabel("t-SNE Dim 2", fontsize=10)
#    ax.grid(True, linestyle='--', alpha=0.25)
#    ax.legend(frameon=False, fontsize=9)
#
#    plt.tight_layout()
#    plt.savefig(filename + ".png", dpi=300, bbox_inches='tight')
#    plt.savefig(filename + ".pdf", bbox_inches='tight')
#    print(f"Saved {filename}.png and {filename}.pdf")
#    plt.show()
#
#
## --- 4. Main ---
#if __name__ == "__main__":
#    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
#    NUM_POS_USERS = 131
#    SAMPLE_NEGATIVES = 1  # negatives per behaviour
#
#    RATIONALE_ENCODER_PATH = "/storage/SFTrecc/[53e_onlyphi_10n_9k]rationale_encoder.pth"
#    BEHAVIOR_ENCODER_PATH = "/storage/SFTrecc/[53e_onlyphi_10n_9k]behavior_encoder.pth"
#    RATIONALES_FILE_PATH = "/storage/Pervez/[onlyphi_9k]thought_spacedata.json"
#
#    # Load data
#    with open(RATIONALES_FILE_PATH, 'r') as f:
#        full_data = json.load(f)
#
#    pos_users = full_data[:NUM_POS_USERS]
#    neg_users = full_data[NUM_POS_USERS:373]  # disjoint set
#
#    tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
#
#    # --- Before training ---
#    print("\n--- Before Training ---")
#    R_encoder_raw = ThoughtEncoder().to(DEVICE)
#    B_encoder_raw = ThoughtEncoder().to(DEVICE)
#
#    all_vecs, labels, pos_vecs, beh_vecs, neg_vecs, pos_texts, beh_texts, neg_texts, user_neg_indices = generate_vectors_with_negatives(
#        R_encoder_raw, B_encoder_raw, tokenizer, pos_users, neg_users,
#        DEVICE, sample_negatives=SAMPLE_NEGATIVES
#    )
#
#    perplexity = min(30, max(5, len(all_vecs) - 1))  # safe lower bound
#    vecs_2d = run_tsne(all_vecs, perplexity=perplexity)
#
#    plot_space_with_mapping(vecs_2d, labels, pos_vecs, beh_vecs, neg_vecs,
#                            pos_texts, beh_texts, neg_texts, user_neg_indices,
#                            "Thought Space Mapping (Before Training)",
#                            "5thought_space_before_mapping_neat",
#                            max_lines=13, annotate_first_n=1,
#                            wrap_width=40, wrap_lines=7, font_size=8)
#
#    # --- After training ---
#    print("\n--- After Training ---")
#    R_encoder_trained, B_encoder_trained = load_trained_models(RATIONALE_ENCODER_PATH,
#                                                               BEHAVIOR_ENCODER_PATH, DEVICE)
#
#    all_vecs, labels, pos_vecs, beh_vecs, neg_vecs, pos_texts, beh_texts, neg_texts, user_neg_indices = generate_vectors_with_negatives(
#        R_encoder_trained, B_encoder_trained, tokenizer, pos_users, neg_users,
#        DEVICE, sample_negatives=SAMPLE_NEGATIVES
#    )
#
#    perplexity = min(30, max(5, len(all_vecs) - 1))
#    vecs_2d = run_tsne(all_vecs, perplexity=perplexity)
#
#    plot_space_with_mapping(vecs_2d, labels, pos_vecs, beh_vecs, neg_vecs,
#                            pos_texts, beh_texts, neg_texts, user_neg_indices,
#                            "Thought Space Mapping (After Training)",
#                            "5thought_space_after_mapping_neat",
#                            max_lines=13, annotate_first_n=1,
#                            wrap_width=40, wrap_lines=7, font_size=8)
#


import json
import torch
from transformers import AutoTokenizer, AutoModel
from tqdm import tqdm
import numpy as np
from sklearn.manifold import TSNE
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt
import seaborn as sns
import random
import textwrap
from shapely.geometry import MultiPoint, Polygon, MultiPolygon, GeometryCollection

# --- 0. SETUP: Model ---
class ThoughtEncoder(torch.nn.Module):
    def __init__(self, model_name="distilbert-base-uncased"):
        super(ThoughtEncoder, self).__init__()
        self.transformer = AutoModel.from_pretrained(model_name)

    def forward(self, input_ids, attention_mask):
        outputs = self.transformer(input_ids=input_ids, attention_mask=attention_mask)
        return outputs.last_hidden_state[:, 0]  # CLS embedding

def load_trained_models(rationale_path, behavior_path, device):
    rationale_encoder = ThoughtEncoder().to(device)
    behavior_encoder = ThoughtEncoder().to(device)
    rationale_encoder.load_state_dict(torch.load(rationale_path, map_location=device))
    behavior_encoder.load_state_dict(torch.load(behavior_path, map_location=device))
    rationale_encoder.eval()
    behavior_encoder.eval()
    return rationale_encoder, behavior_encoder

# --- Utility: wrap & truncate text ---
def wrap_and_truncate(text, width=40, max_lines=6, max_chars=400):
    if text is None:
        return ""
    text = text.strip().replace("\n", " ")
    if len(text) > max_chars:
        text = text[:max_chars].rstrip() + "…"
    wrapped = textwrap.fill(text, width=width)
    lines = wrapped.splitlines()
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1].rstrip() + " …"
    return "\n".join(lines)

def wrap_and_truncate2(text, width=40, max_lines=6, max_chars=1100):
    if text is None:
        return ""
    text = text.strip().replace("\n", " ")
    if len(text) > max_chars:
        text = text[:max_chars].rstrip() + "…"
    wrapped = textwrap.fill(text, width=width)
    lines = wrapped.splitlines()
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1].rstrip() + " …"
    return "\n".join(lines)


def clean_for_display(text):
    if not isinstance(text, str):
        return ""
    s = text.strip()
    if s.startswith("{") and "rationale" in s:
        import re
        m = re.search(r"'rationale'\s*:\s*'(.+)'", s)
        if m:
            return m.group(1)
    return text

# --- 1. Generate vectors with negatives ---
def generate_vectors_with_negatives(R_encoder, B_encoder, tokenizer,
                                    pos_users, neg_users,
                                    device, max_length=256, sample_negatives=1,
                                    seed=42):
    random.seed(seed)
    pos_rationale_vecs, behavior_vecs, neg_rationale_vecs = [], [], []
    pos_texts, beh_texts, neg_texts = [], [], []
    user_neg_indices = []

    R_encoder.eval()
    B_encoder.eval()

    with torch.no_grad():
        for item in tqdm(pos_users, desc="Encoding Positives + Behaviors"):
            rationale_text = clean_for_display(item.get('reason', ''))
            tok_rationale = tokenizer(rationale_text, max_length=max_length,
                                      padding='max_length', truncation=True,
                                      return_tensors='pt').to(device)
            vec_pos = R_encoder(**tok_rationale).cpu().numpy()
            pos_rationale_vecs.append(vec_pos)
            pos_texts.append(rationale_text)

            behavior_context = f"[CONTEXT] History: {item.get('item','')} [CHOSEN_ITEM] {item.get('answer','')}"
            tok_behavior = tokenizer(behavior_context, max_length=max_length,
                                     padding='max_length', truncation=True,
                                     return_tensors='pt').to(device)
            vec_bhv = B_encoder(**tok_behavior).cpu().numpy()
            behavior_vecs.append(vec_bhv)
            beh_texts.append(behavior_context)

            k = min(sample_negatives, max(1, len(neg_users)))
            sampled_negs = random.sample(neg_users, k) if k <= len(neg_users) else random.choices(neg_users, k=k)
            neg_indices_for_user = []
            for neg_item in sampled_negs:
                neg_text = clean_for_display(neg_item.get('reason', ''))
                tok_neg = tokenizer(neg_text, max_length=max_length,
                                    padding='max_length', truncation=True,
                                    return_tensors='pt').to(device)
                vec_neg = R_encoder(**tok_neg).cpu().numpy()
                neg_rationale_vecs.append(vec_neg)
                neg_texts.append(neg_text)
                neg_indices_for_user.append(len(neg_rationale_vecs) - 1)
            user_neg_indices.append(neg_indices_for_user)

    pos_rationale_vecs = np.concatenate(pos_rationale_vecs, axis=0)
    behavior_vecs = np.concatenate(behavior_vecs, axis=0)
    if len(neg_rationale_vecs) > 0:
        neg_rationale_vecs = np.concatenate(neg_rationale_vecs, axis=0)
    else:
        neg_rationale_vecs = np.zeros((0, pos_rationale_vecs.shape[1]))

    labels = (["Positive Rationale"] * len(pos_rationale_vecs) +
              ["Behavior Context"] * len(behavior_vecs) +
              ["Negative Rationale"] * len(neg_rationale_vecs))

    if len(neg_rationale_vecs) > 0:
        all_vecs = np.concatenate([pos_rationale_vecs, behavior_vecs, neg_rationale_vecs], axis=0)
    else:
        all_vecs = np.concatenate([pos_rationale_vecs, behavior_vecs], axis=0)

    return all_vecs, labels, pos_rationale_vecs, behavior_vecs, neg_rationale_vecs, pos_texts, beh_texts, neg_texts, user_neg_indices

# --- 2. t-SNE ---
def run_tsne(vectors, perplexity=30):
    tsne = TSNE(n_components=2, verbose=1, perplexity=perplexity, max_iter=1000, random_state=42, init="pca")
    return tsne.fit_transform(vectors)



from shapely.geometry import MultiPoint, Polygon, MultiPolygon
from matplotlib.patches import Polygon as MplPolygon

def add_buffer_patch(ax, multipoint, facecolor, edgecolor, alpha=0.25, zorder=0, buffer_distance=0.08):
    buffered = multipoint.buffer(buffer_distance)
    
    if buffered.is_empty:
        return

    # Convert to a list of Polygons
    polys = []
    if isinstance(buffered, Polygon):
        polys = [buffered]
    elif isinstance(buffered, MultiPolygon):
        polys = list(buffered.geoms)
    
    for poly in polys:
        if poly.is_empty or poly.exterior is None:
            continue
        coords = np.array(poly.exterior.coords)
        ax.add_patch(MplPolygon(coords, facecolor=facecolor, edgecolor=edgecolor,
                                alpha=alpha, zorder=zorder))



# --- 4. Plot with mapping + buffered hulls + CI regression ---
def plot_space_with_mapping(vectors_2d, labels, pos_vecs, beh_vecs, neg_vecs,
                            pos_texts, beh_texts, neg_texts, user_neg_indices,
                            title, filename, max_lines=10, annotate_first_n=1,
                            wrap_width=50, wrap_lines=7, font_size=8,
                            buffer_distance=0.08):
    fig, ax = plt.subplots(figsize=(10, 10))
    plt.rcParams.update({'font.size': font_size})

    colors = {
        'Positive Rationale': '#1f77b4',
        'Negative Rationale': '#d62728',
        'Behavior Context': '#2ca02c'
    }

    pos_count, beh_count, neg_count = len(pos_vecs), len(beh_vecs), len(neg_vecs)
    pos_idx = list(range(0, pos_count))
    beh_idx = list(range(pos_count, pos_count + beh_count))
    neg_idx = list(range(pos_count + beh_count, pos_count + beh_count + neg_count))
    pos_points, beh_points = vectors_2d[pos_idx], vectors_2d[beh_idx]
    neg_points = vectors_2d[neg_idx] if neg_count > 0 else np.zeros((0, 2))

    ax.scatter(pos_points[:, 0], pos_points[:, 1], c=colors["Positive Rationale"], label="Positive Rationale", alpha=0.85, s=40, edgecolors='k', lw=0.2)
    ax.scatter(beh_points[:, 0], beh_points[:, 1], c=colors["Behavior Context"], label="Behavior Context", alpha=0.9, s=50, edgecolors='k', lw=0.2)
    if neg_count > 0:
        ax.scatter(neg_points[:, 0], neg_points[:, 1], c=colors["Negative Rationale"], label="Negative Rationale", alpha=0.85, s=45)

    # Connect behavior -> positive
    line_indices = list(range(min(max_lines, beh_count)))
    for i in line_indices:
        ax.plot([beh_points[i, 0], pos_points[i, 0]],
                [beh_points[i, 1], pos_points[i, 1]], '-', color='tab:blue', alpha=0.45, linewidth=0.9)

    # Connect behavior -> farthest negative
    if neg_count > 0:
        for i in line_indices:
            neg_indices_for_user = user_neg_indices[i]
            if len(neg_indices_for_user) == 0:
                continue
            user_negs = neg_vecs[neg_indices_for_user]
            sims = cosine_similarity(beh_vecs[i:i+1], user_negs)[0]
            farthest_local_idx = int(np.argmin(sims))
            global_neg_idx = neg_indices_for_user[farthest_local_idx]
            if global_neg_idx < neg_count:
                nx, ny = neg_points[global_neg_idx]
                bx, by = beh_points[i]
                ax.plot([bx, nx], [by, ny], '--', color='tab:red', alpha=0.45, linewidth=0.9)

    # CI regression line for Behavior points
    import pandas as pd
    df_beh = pd.DataFrame({'x': beh_points[:, 0], 'y': beh_points[:, 1]})
    #sns.regplot(data=df_beh, x='x', y='y', scatter=False, ci=95, color='purple', line_kws={'linewidth':1.5}, ax=ax)

    # Add buffered convex hull patches
    first_n = min(annotate_first_n, beh_count)
    
    add_buffer_patch(ax, MultiPoint(pos_points[:7]), facecolor='lightblue', edgecolor='blue', buffer_distance=buffer_distance)
    add_buffer_patch(ax, MultiPoint(beh_points[:7]), facecolor='lightgreen', edgecolor='green', buffer_distance=buffer_distance)
    if neg_count >= first_n:
        add_buffer_patch(ax, MultiPoint(neg_points[:7]), facecolor='#f4cccc', edgecolor='red', buffer_distance=buffer_distance)

    # Annotate first few
    for idx in range(first_n):
        bx, by = beh_points[idx]
        px, py = pos_points[idx]
        beh_display = wrap_and_truncate(beh_texts[idx], width=wrap_width, max_lines=wrap_lines)
        pos_display = wrap_and_truncate(pos_texts[idx], width=wrap_width, max_lines=wrap_lines)
        neg_display = wrap_and_truncate2(neg_texts[4], width=wrap_width, max_lines=wrap_lines)

        bx_off, by_off = (-79, -167)
        px_off, py_off = (60, 205)
        nx_off, ny_off = (398, 291)

        ax.annotate(beh_display, xy=(bx, by), xytext=(bx_off, by_off), textcoords='offset points',
                    fontsize=font_size, ha='left', va='bottom',
                    bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="0.2", lw=0.6, alpha=0.95),
                    arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=0.15", color="black", lw=0.8))
        ax.annotate(pos_display[37:-2], xy=(px, py), xytext=(px_off, py_off), textcoords='offset points',
                    fontsize=font_size, ha='left', va='top',
                    bbox=dict(boxstyle="round,pad=0.3", fc="lightblue", ec="0.2", lw=0.6, alpha=0.95),
                    arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=-0.15", color="black", lw=0.8))
        ax.annotate(neg_display[119:], xy=(nx, ny), xytext=(nx_off, ny_off), textcoords='offset points',
                    fontsize=font_size, ha='left', va='top',
                    bbox=dict(boxstyle="round,pad=0.3", fc="#f4cccc", ec="0.2", lw=0.6, alpha=0.95),
                    arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=-0.15", color="black", lw=0.8))
        print(neg_display)

    ax.set_title(title, fontsize=16, fontweight='bold')

    ax.set_xlabel("t-SNE Dim 1", fontsize=14)
    ax.set_ylabel("t-SNE Dim 2", fontsize=14)
    ax.grid(True, linestyle='--', alpha=0.25)
    ax.legend(frameon=True, fontsize=10)
    plt.tight_layout()
    plt.savefig(filename + ".png", dpi=300, bbox_inches='tight')
    plt.savefig(filename + ".pdf", bbox_inches='tight')
    plt.show()

# --- 5. Main ---
if __name__ == "__main__":
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    NUM_POS_USERS = 137
    SAMPLE_NEGATIVES = 1
    BUFFER_DISTANCE = 1

    RATIONALE_ENCODER_PATH = "/storage/SFTrecc/[53e_onlyphi_10n_9k]rationale_encoder.pth"
    BEHAVIOR_ENCODER_PATH = "/storage/SFTrecc/[53e_onlyphi_10n_9k]behavior_encoder.pth"
    RATIONALES_FILE_PATH = "/storage/Pervez/[onlyphi_9k]thought_spacedata.json"

    with open(RATIONALES_FILE_PATH, 'r') as f:
        full_data = json.load(f)

    pos_users = full_data[:NUM_POS_USERS]
    neg_users = full_data[NUM_POS_USERS:373]

    tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")

    # --- Before training ---
    R_encoder_raw = ThoughtEncoder().to(DEVICE)
    B_encoder_raw = ThoughtEncoder().to(DEVICE)

    all_vecs, labels, pos_vecs, beh_vecs, neg_vecs, pos_texts, beh_texts, neg_texts, user_neg_indices = generate_vectors_with_negatives(
        R_encoder_raw, B_encoder_raw, tokenizer, pos_users, neg_users,
        DEVICE, sample_negatives=SAMPLE_NEGATIVES
    )

    perplexity = min(30, max(5, len(all_vecs) - 1))
    vecs_2d = run_tsne(all_vecs, perplexity=perplexity)

    plot_space_with_mapping(vecs_2d, labels, pos_vecs, beh_vecs, neg_vecs,
                            pos_texts, beh_texts, neg_texts, user_neg_indices,
                            "(3.a) Thought Space Mapping - Before Training",
                            "thought2_space_before_mapping_neat",
                            max_lines=13, annotate_first_n=1,
                            wrap_width=40, wrap_lines=7, font_size=8,
                            buffer_distance=BUFFER_DISTANCE)

    # --- After training ---
    R_encoder_trained, B_encoder_trained = load_trained_models(RATIONALE_ENCODER_PATH,
                                                               BEHAVIOR_ENCODER_PATH, DEVICE)

    all_vecs, labels, pos_vecs, beh_vecs, neg_vecs, pos_texts, beh_texts, neg_texts, user_neg_indices = generate_vectors_with_negatives(
        R_encoder_trained, B_encoder_trained, tokenizer, pos_users, neg_users,
        DEVICE, sample_negatives=SAMPLE_NEGATIVES
    )

    perplexity = min(30, max(5, len(all_vecs) - 1))
    vecs_2d = run_tsne(all_vecs, perplexity=perplexity)

    plot_space_with_mapping(vecs_2d, labels, pos_vecs, beh_vecs, neg_vecs,
                            pos_texts, beh_texts, neg_texts, user_neg_indices,
                            "(3.b) Thought Space Mapping - After Training",
                            "thought2_space_after_mapping_neat",
                            max_lines=13, annotate_first_n=1,
                            wrap_width=40, wrap_lines=7, font_size=8,
                            buffer_distance=BUFFER_DISTANCE)
